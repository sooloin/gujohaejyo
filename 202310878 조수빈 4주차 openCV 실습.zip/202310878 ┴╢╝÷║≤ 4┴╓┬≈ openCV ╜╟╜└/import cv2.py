import cv2
import numpy as np

img = cv2.imread("D:/penguin.jpg", cv2.IMREAD_COLOR)
height, width = img.shape[:2]
M = np.array([[1, 0, 100], [0, 1, 200], [0, 0, 1]], dtype=float)

dst = np.zeros(img.shape, dtype=np.uint8)

for y in range(height-1):
    for x in range(width-1):
        p = np.array([x, y, 1])
        p_ = np.dot(M, p)

        x_, y_ = p_[:2]
        x_ = int(x_)
        y_ = int(y_)

        if 0 < x_ < width and 0 < y_ < height:
            dst[y_, x_] = img[y, x]

result = cv2.hconcat([img, dst])
cv2.imshow("result", result)
cv2.waitKey(0)
cv2.destroyAllWindows()
